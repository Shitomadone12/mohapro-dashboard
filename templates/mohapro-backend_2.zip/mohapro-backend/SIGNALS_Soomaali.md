# Live Signals — Real Pairs (Hage)

Panel cusub oo dashboard-ka lagu daray. Wuxuu tusaa **UP / DOWN / WAIT** + confidence (RSI + EMA + Momentum) 6 lammaanood oo suuq **dhab ah** ah.

> ⚠️ **Lammaanayaasha suuqa DHABTA ah oo kaliya (Isniin–Jimce). MAAHA OTC.** OTC-ga (Pocket Option/IQ Option) waa synthetic — lama xisaabin karo halkan. Kani waa **kaaliye falanqayn**, MA dammaanad qaado guul. Khatar sare — lacag yar ku tijaabi.

---

## Sida loo shido (1 tallaabo oo dheeraad ah)

Signal-ku wuxuu u baahan yahay xog sicir oo dhab ah. Waxaan isticmaalnaa **Twelve Data** (bilaash: 800 codsi/maalin).

### 1) Hel API key bilaash
1. Gal https://twelvedata.com → **Sign up** (bilaash).
2. Dashboard-kooda → **API Key** → koobiyow.

### 2) Geli Render
1. Render → service-kaaga → **Environment** → **Add Environment Variable**.
2. **Key:** `TWELVEDATA_KEY`
3. **Value:** key-gaaga.
4. Save → Render wuu dib u deploy-gareeyaa.

### 3) Cusboonaysii koodhka (haddii aadan weli sameyn)
Ku shub `app.py` iyo `templates/index.html` (nooca cusub) GitHub → Render auto-deploy.

---

## Isticmaalka
- Fur `https://mohapro-dashboard-1.onrender.com/` → panel-ka **"Live Signals — Real Pairs"** wuxuu ku cusboonaysiin doonaa 60 ilbiriqsi kasta.
- **▲ UP** (cagaar) = TA bias kor · **▼ DOWN** (casaan) = hoos · **● WAIT** = cad ma jiro.
- **Conf %** = xoogga signal-ka (RSI+EMA+Momentum iswaafajiyay).

## Alerts & Countdown (cusub)
- **🔔 Alerts:** riix badhanka "Alerts: OFF" → ON. Marka signal xoog leh (Conf ≥ 70%) yimaado oo jihadu isbeddesho, waxaad maqli doontaa **cod (beep)** oo cell-ku wuxuu **flash-gareeyaa** (giraan dahab). Waxaa kaloo iman kara **browser notification** (fasax marka la weydiiyo).
  - Cod-ku wuxuu u baahan yahay in aad marka hore riixdo badhanka (browser-ku wuxuu xannibaa cod otomaatig ah ilaa gujin).
- **⏱ Candle Countdown:** "Next 5min: MM:SS" — waqtiga ku hadhay xidhitaanka candle-ka. Binary entry-ga waxaa badanaa lagu bilaabaa bilowga candle cusub — sug ilaa timer-ku gaaro 00:00 kadibna gal. (Waa qiyaas — ku saleysan UTC candle boundaries.)

## Beddel (ikhtiyaari, `app.py`)
- `SIGNAL_PAIRS` — lammaanayaasha (default 6 majors).
- `SIGNAL_INTERVAL` — `1min`, `5min`, `15min` (env var `SIGNAL_INTERVAL`).
- `SIGNAL_CACHE_SEC` — inta u dhaxaysa codsiyada (rate limit ilaalin).

> Twelve Data free = 8 codsi/daqiiqo. 6 lammaanood + cache 60s waa ammaan. Ha kordhin lammaanayaal badan haddii aad rate limit ka fogaanayso.

---

## Xusuusin daacadnimo ah
Ma jiro signal "adag" oo dammaanad qaada binary. Payout 80% wuxuu u baahan yahay win rate >55% si aad break-even u gaarto. Isticmaal money management adag (lacag yar trade kasta, xad maalinle), oo ha ku dhicin dadka iibiya "signals 90%+" — badankood waa khiyaano.

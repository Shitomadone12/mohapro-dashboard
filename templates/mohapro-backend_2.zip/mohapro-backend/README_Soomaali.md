# MOHA PRO — Cloud Dashboard Backend (Render)

Server Python/Flask ah oo:
- Ka hela xogta bootka MT4 (`POST /update`)
- Siiya dashboard-ka xogta (`GET /state`)
- Bixiya amarrada remote-ka bootka (`GET /api/commands`)
- Ogolaada admin inuu diro amar (`POST /admin/command`)
- Adeegaa **dashboard-ka** (`/`) iyo **admin panel-ka** (`/admin`)

> **Bootka `.mq4` waxba looma beddelin.** Kani wuxuu la shaqeeyaa `CloudDashboardURL`, `CloudCommandURL`, iyo `Cloud_Auth_Token` sida ay hadda u yihiin.

---

## Faylasha

| Fayl | Micno |
|---|---|
| `app.py` | Server-ka Flask (backend) |
| `requirements.txt` | Xirmooyinka (Flask, gunicorn) |
| `render.yaml` | Config Render (auto-detect) |
| `Procfile` | Amarka bilaabista |
| `static/index.html` | Dashboard-ka (professional) |
| `static/admin.html` | Admin control panel |

---

## QAYBTA 1 — Deploy ku samee Render (bilaash)

### Tallaabo 1: Ku shub GitHub
1. Samee GitHub account (haddii aadan lahayn) → https://github.com
2. Samee repo cusub (tusaale `mohapro-dashboard`).
3. Ku shub dhammaan faylasha galkan (`app.py`, `requirements.txt`, `render.yaml`, `Procfile`, iyo galka `static/`).

### Tallaabo 2: Ku xir Render
1. Gal https://render.com → samee account (GitHub ku gal).
2. **New +** → **Web Service** → dooro repo-gaaga.
3. Render wuxuu si toos ah u aqoonsan doonaa `render.yaml`. Haddii kale, geli gacan:
   - **Runtime:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
   - **Plan:** Free

### Tallaabo 3: Geli AUTH_TOKEN
1. Render → service-kaaga → **Environment** → **Add Environment Variable**
2. **Key:** `AUTH_TOKEN`
3. **Value:** isla qiimaha `Cloud_Auth_Token` ee bootka (tusaale `MohaPro_Live_2026_MySecret`).
4. **Save** → Render wuu dib u deploy-gareeyaa.

### Tallaabo 4: Hel URL-kaaga
Render wuxuu ku siin doonaa URL sida:
```
https://mohapro-dashboard.onrender.com
```

---

## QAYBTA 2 — Bootka MT4 u samee config

Inputs-ka EA-ga:

| Setting | Qiimaha |
|---|---|
| `EnableCloudDashboard` | `true` |
| `CloudDashboardURL` | `https://MAGACAAGA.onrender.com/update` |
| `CloudCommandURL` | `https://MAGACAAGA.onrender.com/api/commands` |
| `Cloud_Auth_Token` | isla `AUTH_TOKEN` (tusaale `MohaPro_Live_2026_MySecret`) |
| `Require_Signed_Commands` | `true` |

**Allowlist (MUHIIM):** MT4 → Tools → Options → Expert Advisors → "Allow WebRequest for listed URL" → ku dar:
```
https://MAGACAAGA.onrender.com
```

---

## QAYBTA 3 — Isticmaalka

| Bog | URL |
|---|---|
| **Dashboard** (arag xogta) | `https://MAGACAAGA.onrender.com/` |
| **Admin** (dir amarro) | `https://MAGACAAGA.onrender.com/admin` |

**Admin panel:** geli token-ka → riix badhan (SHID/DAMI/XIR DHAMMAAN/XIR FAA'IIDO ama strategy). Bootku wuxuu qaadan doonaa amarka ~3 ilbiriqsi gudahood.

Dashboard-ku wuxuu si toos ah isugu cusboonaysiiyaa 5 ilbiriqsi kasta. Marka xog dhab ah timaado, calaamadu waxay u beddelmaysaa **● LIVE** (cagaar). Equity curve-na wuxuu ka dhismi doonaa xogta dhabta ah.

---

## Ogaysiisyo muhiim ah

1. **Render Free tier** wuxuu "seexdaa" 15 daqiiqo ka dib firfircooni la'aan. Codsiga koowaad ka dib hurdada waxay qaadan kartaa ~30 ilbiriqsi (cold start) — WebRequest-ka bootku wuu time-out geli karaa mar. Xal: isticmaal plan bixin (paid), ama u samee ping joogto ah (uptime monitor).
2. **State-ka** waa memory (RAM) — wuu dib u bilaabmaa marka server-ku restart-gareeyo. Taasi dashboard-ka waxba kuma dhimayso (xogta cusub bootka ayaa dira). Haddii aad rabto kayd joogto ah, waxaa lagu dari karaa database (Postgres/Redis).
3. **Amniga:** `/state` waa furan yahay (wuxuu tusayaa balance). Qofkasta oo URL-ka haysta wuu arki karaa. URL-ka ha la wadaagin. (Haddii aad rabto, waxaan ku dari karaa token `/state`-ka.)

---

## Tijaabi gudahaaga (local)

```bash
pip install -r requirements.txt
python app.py
# fur: http://localhost:5000  (dashboard) iyo /admin
```

Tijaabi xogta:
```bash
curl -X POST http://localhost:5000/update \
  -H "Authorization: Bearer MohaPro_Live_2026_MySecret" \
  -H "Content-Type: application/json" \
  -d '{"balance":10500,"equity":10520,"profit":120,"winrate":67,"drawdown":1.8,"opentrades":2,"symbol":"EURUSD"}'
```

"""
MOHA PRO ULTIMATE - Cloud Dashboard Backend
--------------------------------------------
Flask server oo:
  - Ka hela xogta bootka MT4 (POST /update)
  - Siiya dashboard-ka xogta (GET /state)
  - Bixiya amarrada remote-ka bootka (GET /api/commands)
  - Ogolaada in admin uu diro amar (POST /admin/command)
  - Adeegaa dashboard-ka (GET /) iyo admin panel (GET /admin)

Bootka .mq4 waxba looma beddelin - kani wuxuu la shaqeeyaa
CloudDashboardURL=/update iyo CloudCommandURL=/api/commands sida ay yihiin.
"""
import os
import time
import json
import urllib.request
import urllib.parse
from flask import Flask, request, jsonify, send_from_directory, Response

app = Flask(__name__)   # HTML-ka wuxuu ku jiraa galka templates/ (sida repo-gaaga)

# ---- CONFIG (Render env var 'AUTH_TOKEN' -> waa in la mid noqoto Cloud_Auth_Token ee bootka) ----
AUTH_TOKEN = os.environ.get("AUTH_TOKEN", "MohaPro_Live_2026_MySecret")
MAX_HISTORY = 120          # immisa qiimo equity ah oo la kaydiyo (curve-ka)
STALE_SECONDS = 120        # ka dib intaas, xogta waxaa loo tiriyaa "stale" (LIVE off)

# ---- SIGNALS CONFIG (real forex pairs, Twelve Data) ----
TWELVEDATA_KEY = os.environ.get("TWELVEDATA_KEY", "")   # hel bilaash: https://twelvedata.com
SIGNAL_PAIRS = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "EUR/JPY"]
SIGNAL_INTERVAL = os.environ.get("SIGNAL_INTERVAL", "5min")
SIGNAL_CACHE_SEC = 60      # ha ka badan hal codsi 60s kasta (rate limit ilaalin)
_signal_cache = {}         # {symbol: (timestamp, result_dict)}

# ---- In-memory state (Render free tier: waa la lumin karaa marka uu hurdo; ku filan dashboard) ----
state = {
    "balance": None, "equity": None, "profit": None,
    "winrate": None, "drawdown": None, "opentrades": None,
    "symbol": None, "updated": None,
}
equity_history = []        # [float, ...] equity over time
pending_command = None     # amarka soo socda ee bootka


def authorized(req):
    """Ogolaanshaha: Bearer header, ama token JSON body dhexdeeda, ama ?token= query."""
    auth = req.headers.get("Authorization", "")
    if auth.startswith("Bearer ") and auth[7:].strip() == AUTH_TOKEN:
        return True
    data = req.get_json(silent=True) or {}
    if str(data.get("token", "")) == AUTH_TOKEN:
        return True
    if req.args.get("token") == AUTH_TOKEN:
        return True
    return False


@app.after_request
def add_cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


# ============ 1) Bootka -> Server: xogta la cusboonaysiiyo ============
@app.route("/update", methods=["POST", "OPTIONS"])
def update():
    if request.method == "OPTIONS":
        return ("", 204)
    if not authorized(request):
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or {}
    for k in ["balance", "equity", "profit", "winrate", "drawdown", "opentrades", "symbol"]:
        if k in data:
            state[k] = data[k]
    state["updated"] = int(time.time())
    if state.get("equity") is not None:
        try:
            equity_history.append(float(state["equity"]))
            if len(equity_history) > MAX_HISTORY:
                del equity_history[0:len(equity_history) - MAX_HISTORY]
        except (TypeError, ValueError):
            pass
    return jsonify({"ok": True})


# ============ 2) Dashboard <- Server: xogta la akhriyo ============
@app.route("/state", methods=["GET"])
def get_state():
    out = dict(state)
    out["equity_history"] = equity_history
    updated = state["updated"] or 0
    out["live"] = bool(updated) and (time.time() - updated < STALE_SECONDS)
    return jsonify(out)


# ============ 3) Bootka <- Server: amarrada remote-ka ============
# MUHIIM: bootku wuxuu raadiyaa `"token":"<token>"` (meel bannaan la'aan) iyo kelmadaha
# amarka sida "START". Sidaas darteed waxaa loo diraa JSON compact ah (separators=",",":" ).
@app.route("/api/commands", methods=["GET"])
def commands():
    global pending_command
    if not authorized(request):
        return jsonify({"error": "unauthorized"}), 401
    cmd = pending_command or ""
    pending_command = None          # one-shot: mar kaliya ka dib waa la nadiifiyaa
    payload = json.dumps({"token": AUTH_TOKEN, "command": cmd}, separators=(",", ":"))
    return Response(payload, mimetype="application/json")


# ============ 4) Admin -> Server: dir amar ============
VALID_COMMANDS = {
    "START", "STOP", "CLOSE_ALL", "CLOSE_PROFIT",
    "STRATEGY:SR", "STRATEGY:BB", "STRATEGY:EMA",
    "STRATEGY:SMC", "STRATEGY:VSA", "STRATEGY:RSI",
}


@app.route("/admin/command", methods=["POST", "OPTIONS"])
def set_command():
    global pending_command
    if request.method == "OPTIONS":
        return ("", 204)
    if not authorized(request):
        return jsonify({"error": "unauthorized"}), 401
    data = request.get_json(silent=True) or request.form
    cmd = (data.get("command") or "").strip().upper()
    if cmd not in VALID_COMMANDS:
        return jsonify({"error": "invalid command", "allowed": sorted(VALID_COMMANDS)}), 400
    pending_command = cmd
    return jsonify({"ok": True, "queued": cmd})


# ============ SIGNALS (real forex pairs — market hours only) ============
def _ema(values, period):
    if len(values) < period:
        return None
    k = 2.0 / (period + 1)
    e = sum(values[:period]) / period
    for v in values[period:]:
        e = v * k + e * (1 - k)
    return e


def _rsi(values, period=14):
    if len(values) <= period:
        return None
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = values[i] - values[i - 1]
        if d >= 0:
            gains += d
        else:
            losses -= d
    ag, al = gains / period, losses / period
    for i in range(period + 1, len(values)):
        d = values[i] - values[i - 1]
        g = d if d > 0 else 0.0
        l = -d if d < 0 else 0.0
        ag = (ag * (period - 1) + g) / period
        al = (al * (period - 1) + l) / period
    if al == 0:
        return 100.0
    rs = ag / al
    return 100.0 - 100.0 / (1.0 + rs)


def _fetch_closes(symbol, interval, size=60):
    """Twelve Data time_series -> [closes] oldest->newest, iyo datetime u dambeeya."""
    if not TWELVEDATA_KEY:
        return None, None, "no_key"
    q = urllib.parse.urlencode({
        "symbol": symbol, "interval": interval,
        "outputsize": size, "apikey": TWELVEDATA_KEY, "format": "JSON",
    })
    url = "https://api.twelvedata.com/time_series?" + q
    try:
        with urllib.request.urlopen(url, timeout=8) as r:
            data = json.loads(r.read().decode())
    except Exception as e:
        return None, None, "fetch_error: " + str(e)
    if isinstance(data, dict) and data.get("status") == "error":
        return None, None, data.get("message", "api_error")
    vals = data.get("values") or []
    if not vals:
        return None, None, "no_data"
    closes = [float(x["close"]) for x in vals]
    closes.reverse()
    last_dt = vals[0].get("datetime")
    return closes, last_dt, None


def _compute_signal(closes):
    e9 = _ema(closes, 9)
    e21 = _ema(closes, 21)
    r = _rsi(closes, 14)
    mom = closes[-1] - closes[-4] if len(closes) >= 4 else 0.0
    score = 0.0
    reasons = []
    if e9 is not None and e21 is not None:
        if e9 > e21:
            score += 1; reasons.append("EMA↑")
        else:
            score -= 1; reasons.append("EMA↓")
    if r is not None:
        score += (1 if r > 50 else -1) * min(abs(r - 50) / 20.0, 1.0)
        reasons.append("RSI %.0f" % r)
    if mom > 0:
        score += 1; reasons.append("Mom↑")
    elif mom < 0:
        score -= 1; reasons.append("Mom↓")
    direction = "UP" if score > 0.5 else ("DOWN" if score < -0.5 else "NEUTRAL")
    confidence = int(min(abs(score) / 3.0 * 100, 99))
    return {
        "direction": direction, "confidence": confidence,
        "rsi": round(r, 1) if r is not None else None,
        "reasons": reasons,
    }


@app.route("/signals", methods=["GET"])
def signals():
    if not TWELVEDATA_KEY:
        return jsonify({"error": "no_api_key",
                        "hint": "Geli TWELVEDATA_KEY env var (bilaash: twelvedata.com)"}), 200
    out = []
    now = time.time()
    for sym in SIGNAL_PAIRS:
        cached = _signal_cache.get(sym)
        if cached and (now - cached[0] < SIGNAL_CACHE_SEC):
            out.append(cached[1])
            continue
        closes, last_dt, err = _fetch_closes(sym, SIGNAL_INTERVAL)
        if err or not closes or len(closes) < 22:
            item = {"symbol": sym, "direction": "N/A", "confidence": 0,
                    "rsi": None, "reasons": [err or "insufficient"], "time": last_dt}
        else:
            sig = _compute_signal(closes)
            sig["symbol"] = sym
            sig["time"] = last_dt
            item = sig
        _signal_cache[sym] = (now, item)
        out.append(item)
    return jsonify({"pairs": out, "interval": SIGNAL_INTERVAL, "generated": int(now)})


# ============ 5) Pages ============
@app.route("/")
def index():
    return send_from_directory("templates", "index.html")


@app.route("/admin")
def admin_page():
    return send_from_directory("templates", "admin.html")


@app.route("/health")
def health():
    return jsonify({"ok": True, "live": bool(state["updated"])})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)

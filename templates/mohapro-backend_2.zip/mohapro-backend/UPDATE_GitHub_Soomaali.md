# Sida loo cusboonaysiiyo repo-gaaga `mohapro-dashboard`

Repo-gaagu horeba wuu jiraa oo Render wuu ku xiran yahay. Kaliya ku beddel faylasha nooca professional-ka ah. Marka aad commit gareyso, **Render si toos ah ayuu dib u deploy-gareeyaa** (2–3 daqiiqo).

Repo-gaaga hadda: `templates/` · `app.py` · `requirements.txt`
Faylasha cusub ee la rabo: `app.py` · `requirements.txt` · `Procfile` · `templates/index.html` · `templates/admin.html`

---

## HAB A — Telefoonka (GitHub mobile web)

### 1) Faylasha root-ka (`app.py`, `requirements.txt`, `Procfile`)
1. Repo-ga → riix **Add file** → **Upload files**.
2. Dooro (select) faylasha: **app.py**, **requirements.txt**, **Procfile** (kuwa aan kuu soo diray).
3. Hoos → **Commit changes**. (`app.py` iyo `requirements.txt` way ku dul qorayaan kuwii hore.)

### 2) Faylasha `templates/`
1. Riix galka **templates** (si aad u gasho).
2. **Add file** → **Upload files**.
3. Dooro: **index.html** iyo **admin.html**.
4. **Commit changes**. (`index.html` wuu ku dul qorayaa kii hore.)

### 3) Render env var (haddii aan hore loo dejin)
1. Render → service-kaaga → **Environment**.
2. Hubi in `AUTH_TOKEN` = isla `Cloud_Auth_Token` ee bootka (tusaale `MohaPro_Live_2026_MySecret`).
3. Save.

---

## HAB B — Kombuyuutar (ugu sahlan)

1. Repo-ga → **Add file → Upload files** → jiid dhammaan faylasha (iyo galka `templates/`).
2. Commit. Render wuu dib u deploy-gareeyaa.

---

## Ka dib deploy-ka

| Bog | URL |
|---|---|
| Dashboard | `https://mohapro-dashboard-1.onrender.com/` |
| Admin | `https://mohapro-dashboard-1.onrender.com/admin` |

Bootka MT4 (hubi inputs-ka + WebRequest allowlist):
- `CloudDashboardURL = https://mohapro-dashboard-1.onrender.com/update`
- `CloudCommandURL = https://mohapro-dashboard-1.onrender.com/api/commands`
- `Cloud_Auth_Token = <isla AUTH_TOKEN>`
- Allowlist: `https://mohapro-dashboard-1.onrender.com`

---

## Hubinta inuu shaqeeyay
- Fur `/` → waa inaad aragtaa dashboard-ka professional (bilowga "DEMO DATA" ilaa bootku xog diro → "● LIVE").
- Fur `/admin` → geli token → riix badhan → bootku wuu qaadan doonaa ~3 ilbiriqsi.

> Haddii `templates/` uu hore u lahaa faylal kale (tusaale CSS), waxba kuma dhimayaan — app-ku wuxuu isticmaalaa `index.html` iyo `admin.html` kaliya.
